<!DOCTYPE html>
<html>
<head>
<title> Sign Up </title>
<link rel="stylesheet" href="mystyle.css">
</head>
<body>
<div class="wrap">
    <h2> Sign Up Here </h2>
    <form>
        <input type="text" placeholder="First Name" name="first_name" required>
        <input type="text" placeholder="Last Name" name="last_name" required>
        <input type="text" placeholder="Email" name="email" required>
        <input type="text" placeholder="Address" name="addressdt" required>
       
        <input type="password"placeholder="Password" name="pass" required>
        <input type="password"placeholder ="Confirmed Password" name="conpass" required>
        <input type="submit" value="Sign Up">
</div>
</body>