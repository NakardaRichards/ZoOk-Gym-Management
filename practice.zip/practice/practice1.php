<html>
<head>
<meta charset="utf-8"> 
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<title>Testing Code</title>

</head>
<body>
<form method="POST">
    <div class="container">
    <table>
        <tr>
        <div class="form-group">
            <td>Username:<input class="form-control" type="text" name="uname"placeholder="Enter username"> </td>
            </div>
        </tr>
        <tr>
        <div class="form-group">
        <td> Password:<input class="form-control"type="text"name="pass"placeholder="Enter passowrd" ></td>
        </div>
        </tr>
        <tr>
        <div class="form-group">
        <td> Select user type: <select name="usertype">
            <option value="admin">admin</option>
            <option value="user">user</option>
         </td>
        <tr>
        <td>
        <div class="form-group">
            <button type="submit"class="btn btn-success"name="login"value="login">Submit </td>
            </div>
        </tr>
    </table>
    </div>
</form>
</body>
</html>