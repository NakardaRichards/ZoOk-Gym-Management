<html>
<head>
<title>Login<title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>
<body>
<form method="POST">
    <div class="container">
  
        <div class="form-group">
          Username:<input id="text"class="form-control" type="text" name="uname"placeholder="Enter username"> 
            </div>
       
        <div class="form-group">
      Password:<input id="text"class="form-control"type="password"name="pass"placeholder="Enter passowrd" >
        </div>
        
       
        <div class="form-group">
            <button type="submit"class="btn btn-success"name="login"value="login">Sign in </button>
            <a href="signup.php" style="margin:20px"class="btn btn-secondary">Sign Up</a>
            </div>
      
    </div>
</form>
</body>
</html>
<?php
session_start();
include("connection.php");
include("functions.php");
if($_SERVER['REQUEST_METHOD']=="POST")
{
  $user_name=$_POST['uname'];
  $password=$_POST['pass'];
  if(!empty($user_name) && !empty($pass))
  {
      $query="SELECT * FROM users WHERE username='$user_name'limit 1";
      $result=mysliq_query($query);
      if($result){
        if($result&&mysqli_numrows($result)>0){
          $user_data=mysli_fecth_assoc($result);
          if($user_data['password']===$password){
            $_SESSION['user_id']=$user_data['user_id'];
            header("Location:index.php");
            die;
          }
        }
      }
     echo"Wrong username or password";
  }
  else {
      echo "Please enter information!";
  }
}

?>
