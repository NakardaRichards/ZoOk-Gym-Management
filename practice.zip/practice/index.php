<?php
session_start();
    include ("connection.php");
    include("functions.php");
    $user_data=check_login($con)

?>
<html>
<head>
    <title>Welcom</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

</head>
<body>
    <a href="logout.php">Logout</a>
    <h1>Welcome</h1> <br>
   
    Hello<?php echo $user_data['uname'];?>
</body>
</html>